# Financial Application

A web-based financial management tool designed to help users track and organize both personal and business finances through a clean, dedicated interface for each context.

## Overview

Financial Application provides separate, purpose-built views for managing personal and business finances, along with a contact page for user inquiries.

## Features

- **Personal Finance Tracker** – Dedicated interface (`personal.html`) for logging and reviewing individual income and expenses
- **Business Finance Tracker** – Separate interface (`business.html`) tailored to business-related financial tracking
- **Contact Page** – A contact form (`contact.html`) for user support or inquiries
- **Custom Styling & Animations** – Modular CSS for layout, calendar views, contact forms, and UI animations

## Tech Stack

- **Frontend:** HTML, CSS, JavaScript
- **Backend:** Python (Flask structure in place via `__init__.py`)
- **Planned:** Database integration for persistent user data

## Project Structure

```
Financial Application/
├── public/
│   ├── CSS/
│   │   ├── animation.css
│   │   ├── calendar.css
│   │   ├── contact.css
│   │   └── style.css
│   ├── database/
│   ├── js/
│   │   ├── business.js
│   │   └── personal.js
│   ├── static/
│   ├── __init__.py
│   ├── business.html
│   ├── contact.html
│   ├── index.html
│   └── personal.html
├── .gitignore
└── README.md
```

## Current Status

> **Note:** This project is currently operating as a **frontend-only application**. Due to the difficulty of finding a free, reliable backend hosting service, user data persistence (saving financial entries across sessions) has not yet been implemented. All functionality currently runs client-side.
>
> Whether a backend will be added is **not yet decided** — this may remain a frontend-only demo or evolve into a full-stack application depending on future direction.


## Roadmap

- [ ] Decide whether a backend will be added
- [ ] *(If added)* Integrate a backend service for persistent data storage
- [ ] *(If added)* Add user authentication
- [ ] *(If added)* Connect a database for saving personal and business financial records
- [ ] *(If added)* Deploy to a live hosting environment

## License

This project is currently unlicensed. All rights reserved by the author.

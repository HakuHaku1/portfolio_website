const months = ['January','February','March','April','May','June',
                    'July','August','September','October','November','December'];
const monthShort = ['Jan','Feb','Mar','Apr','May','Jun',
                    'Jul','Aug','Sep','Oct','Nov','Dec'];
const dayLabels = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];

const monthlyRevenue = {};
const monthlyCost = {};

const categoryLabels = ['COGS', 'Marketing', 'Salaries', 'Utilities', 'Rent', 'Other'];
const categoryTotals = { COGS: 0, Marketing: 0, Salaries: 0, Utilities: 0, Rent: 0, Other: 0 };

function getAllMonthsThisYear() {
    const result = [];
    const year = new Date().getFullYear();
    for (let i = 0; i < 12; i++) {
        result.push({
            label: monthShort[i],
            key: `${year}-${String(i + 1).padStart(2, '0')}`
        });
    }
    return result;
}

const lineCtx = document.getElementById('businessLineChart').getContext('2d');
const lineChart = new Chart(lineCtx, {
    type: 'line',
    data: {
        labels: getAllMonthsThisYear().map(m => m.label),
        datasets: [
            {
                label: 'Revenue (₱)',
                data: getAllMonthsThisYear().map(m => monthlyRevenue[m.key] || 0),
                borderColor: '#4CAF50',
                backgroundColor: 'rgba(76, 175, 80, 0.1)',
                tension: 0.4,
                fill: true
            },
            {
                label: 'Cost (₱)',
                data: getAllMonthsThisYear().map(m => monthlyCost[m.key] || 0),
                borderColor: '#e74c3c',
                backgroundColor: 'rgba(231, 76, 60, 0.1)',
                tension: 0.4,
                fill: true
            }
        ]
    },
    options: { responsive: true }
});

function getCurrencySymbol() {
    return {
        PHP: '₱',
        USD: '$',
        EUR: '€',
        JPY: '¥',
        GBP: '£'
    }[businessCurrencySelect.value] || '₱';
}

function updateLineChart() {
    const symbol = getCurrencySymbol();
    const allMonths = getAllMonthsThisYear();
    lineChart.data.labels = allMonths.map(m => m.label);
    lineChart.data.datasets[0].data = allMonths.map(m => monthlyRevenue[m.key] || 0);
    lineChart.data.datasets[1].data = allMonths.map(m => monthlyCost[m.key] || 0);
    lineChart.data.datasets[0].label = `Revenue (${symbol})`;
    lineChart.data.datasets[1].label = `Cost (${symbol})`;
    lineChart.update();
}

const barCtx = document.getElementById('businessBarChart').getContext('2d');
const barChart = new Chart(barCtx, {
    type: 'bar',
    data: {
        labels: categoryLabels,
        datasets: [{
            label: 'Cost (₱)',
            data: categoryLabels.map(c => categoryTotals[c]),
            backgroundColor: ['#3498db', '#f39c12', '#9b59b6', '#1abc9c', '#e67e22', '#95a5a6']
        }]
    },
    options: { scales: { y: { beginAtZero: true } } }
});

function updateBarChart() {
    const symbol = getCurrencySymbol();
    barChart.data.datasets[0].data = categoryLabels.map(c => categoryTotals[c]);
    barChart.data.datasets[0].label = `Cost (${symbol})`;
    barChart.update();
}

let current = new Date();
let selectedDate = null;
let entries = {};

function dateKey(year, month, day) {
    return `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
}

function monthKey(dateKeyStr) {
    return dateKeyStr.slice(0, 7);
}

const entryType = document.getElementById('businessEntryType');
const categoryWrapper = document.getElementById('businessCategoryWrapper');
const taxRateInput = document.getElementById('businessTaxRate');
const businessCurrencySelect = document.getElementById('businessCurrency');
const businessCurrencySymbol = document.getElementById('businessCurrencySymbol');
const revenueEl = document.getElementById('businessRevenue');
const costEl = document.getElementById('businessCost');
const taxEl = document.getElementById('businessTax');
const profitEl = document.getElementById('businessProfit');

function formatCurrency(amount) {
    const symbol = getCurrencySymbol();
    return `${symbol}${amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

entryType.addEventListener('change', () => {
    categoryWrapper.style.display = entryType.value === 'expense' ? 'block' : 'none';
});

taxRateInput.addEventListener('input', updateBusinessSummary);
businessCurrencySelect.addEventListener('change', () => {
    businessCurrencySymbol.textContent = getCurrencySymbol();
    updateBusinessSummary();
    updateLineChart();
    updateBarChart();
    renderEntriesLog(selectedDate);
});


function updateBusinessSummary() {
    const totalRevenue = Object.values(monthlyRevenue).reduce((sum, value) => sum + value, 0);
    const totalCost = Object.values(monthlyCost).reduce((sum, value) => sum + value, 0);
    const taxRate = parseFloat(taxRateInput.value) || 0;
    const taxAmount = Math.round(totalRevenue * (taxRate / 100) * 100) / 100;
    const profit = Math.round((totalRevenue - totalCost - taxAmount) * 100) / 100;

    revenueEl.textContent = formatCurrency(totalRevenue);
    costEl.textContent = formatCurrency(totalCost);
    taxEl.textContent = formatCurrency(taxAmount);
    profitEl.textContent = formatCurrency(profit);
}

function populateShortcuts() {
    const daySelect = document.getElementById('jumpDay');
    daySelect.innerHTML = '<option value="">Day</option>';
    for (let d = 1; d <= 31; d++) {
        daySelect.innerHTML += `<option value="${d}">${d}</option>`;
    }

    const monthSelect = document.getElementById('jumpMonth');
    monthSelect.innerHTML = '<option value="">Month</option>';
    months.forEach((m, i) => {
        monthSelect.innerHTML += `<option value="${i}">${m}</option>`;
    });

    const yearSelect = document.getElementById('jumpYear');
    const thisYear = new Date().getFullYear();
    yearSelect.innerHTML = '<option value="">Year</option>';
    for (let y = thisYear - 5; y <= thisYear + 2; y++) {
        yearSelect.innerHTML += `<option value="${y}">${y}</option>`;
    }
}

function renderCalendar() {
    const year = current.getFullYear();
    const month = current.getMonth();
    document.getElementById('monthLabel').textContent = `${months[month]} ${year}`;

    document.getElementById('jumpMonth').value = month;
    document.getElementById('jumpYear').value = year;
    if (selectedDate) {
        const [, , d] = selectedDate.split('-');
        document.getElementById('jumpDay').value = parseInt(d, 10);
    }

    const grid = document.getElementById('calendarGrid');
    grid.innerHTML = '';

    dayLabels.forEach(d => {
        const el = document.createElement('div');
        el.className = 'day-label';
        el.textContent = d;
        grid.appendChild(el);
    });

    const firstDay = new Date(year, month, 1).getDay();
    for (let i = 0; i < firstDay; i++) {
        const el = document.createElement('div');
        el.className = 'day empty';
        grid.appendChild(el);
    }

    const daysInMonth = new Date(year, month + 1, 0).getDate();
    for (let d = 1; d <= daysInMonth; d++) {
        const el = document.createElement('div');
        el.className = 'day';
        el.textContent = d;

        const key = dateKey(year, month, d);
        if (entries[key] && entries[key].length > 0) el.classList.add('has-entry');
        if (selectedDate && selectedDate === key) el.classList.add('selected');

        el.addEventListener('click', () => {
            selectedDate = key;
            document.getElementById('jumpDay').value = d;
            openForm(key);
            renderCalendar();
        });

        grid.appendChild(el);
    }
}

function openForm(key) {
    const [year, month, day] = key.split('-');
    document.getElementById('formDateLabel').textContent =
        `${months[parseInt(month, 10) - 1]} ${parseInt(day, 10)}, ${year}`;
    document.getElementById('entryForm').classList.add('open');
    document.getElementById('businessEntryDesc').value = '';
    document.getElementById('businessEntryAmount').value = '';
    entryType.value = 'income';
    categoryWrapper.style.display = 'none';
    renderEntriesLog(key);
}

function renderEntriesLog(key) {
    const log = document.getElementById('businessEntriesLog');
    const dayEntries = entries[key] || [];

    if (dayEntries.length === 0) {
        log.innerHTML = '<p style="color:#999; font-size:0.9rem; margin-top:0.5rem;">No entries for this day.</p>';
        return;
    }

    log.innerHTML = dayEntries.map(e => `
        <div class="entry-item">
            <span>
                ${e.desc}
                ${e.category ? `<em style="color:#999; font-size:0.8rem;">[${e.category}]</em>` : ''}
            </span>
            <span class="${e.type}">
            ${e.type === 'income' ? '+' : '-'}${formatCurrency(parseFloat(e.amount))}
            </span>
        </div>
    `).join('');
}

document.getElementById('businessAddEntryBtn').addEventListener('click', () => {
    const type = entryType.value;
    const desc = document.getElementById('businessEntryDesc').value.trim();
    const amount = parseFloat(document.getElementById('businessEntryAmount').value);
    const category = type === 'expense'
        ? document.getElementById('businessEntryCategory').value
        : null;

    if (!desc || !amount) {
        alert('Please fill in both description and amount.');
        return;
    }

    if (!entries[selectedDate]) entries[selectedDate] = [];
    entries[selectedDate].push({ type, desc, amount, category });

    const mKey = monthKey(selectedDate);

    if (type === 'income') {
        monthlyRevenue[mKey] = (monthlyRevenue[mKey] || 0) + amount;
    } else {
        monthlyCost[mKey] = (monthlyCost[mKey] || 0) + amount;
        if (category) {
            categoryTotals[category] = (categoryTotals[category] || 0) + amount;
            updateBarChart();
        }
    }

    updateLineChart();
    updateBusinessSummary();

    document.getElementById('businessEntryDesc').value = '';
    document.getElementById('businessEntryAmount').value = '';

    renderCalendar();
    renderEntriesLog(selectedDate);
});

document.getElementById('prevMonth').addEventListener('click', () => {
    current.setMonth(current.getMonth() - 1);
    renderCalendar();
});

document.getElementById('nextMonth').addEventListener('click', () => {
    current.setMonth(current.getMonth() + 1);
    renderCalendar();
});

document.getElementById('jumpBtn').addEventListener('click', () => {
    const day = document.getElementById('jumpDay').value;
    const month = document.getElementById('jumpMonth').value;
    const year = document.getElementById('jumpYear').value;

    if (month !== '') current.setMonth(parseInt(month, 10));
    if (year !== '') current.setFullYear(parseInt(year, 10));

    if (day !== '' && month !== '' && year !== '') {
        const key = dateKey(parseInt(year, 10), parseInt(month, 10), parseInt(day, 10));
        selectedDate = key;
        openForm(key);
    }

    renderCalendar();
});

populateShortcuts();
selectedDate = dateKey(current.getFullYear(), current.getMonth(), current.getDate());
renderCalendar();
openForm(selectedDate);
updateBusinessSummary();

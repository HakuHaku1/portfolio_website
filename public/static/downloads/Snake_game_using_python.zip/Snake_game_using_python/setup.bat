@echo off
cd /d "%~dp0"
set "PYTHON=python"
python --version >nul 2>&1
if errorlevel 1 (
    py --version >nul 2>&1
    if errorlevel 1 (
        echo.
        echo Python was not found on your PATH.
        echo Install Python 3.8 or newer from https://www.python.org/downloads/ and run this script again.
        pause
        exit /b 1
    ) else (
        set "PYTHON=py"
    )
)
echo Using %PYTHON%.
echo Creating virtual environment...
%PYTHON% -m venv venv
if errorlevel 1 (
    echo.
    echo Failed to create the virtual environment.
    pause
    exit /b 1
)
echo Activating virtual environment and upgrading pip...
call venv\Scripts\activate.bat
python -m pip install --upgrade pip
echo.
echo Setup complete.
echo To start the game, run start.bat.
pause

from turtle import Turtle
Starting = [(0,0), (-20,0), (-40,0)]

class Snake:
    def __init__(self):
        self.segment = []
        self.create_snake()

    def create_snake(self):
        for position in Starting:

            self.add_segment(position)
    def add_segment(self,position):
        segment_1 = Turtle("square")
        segment_1.color("white")
        segment_1.penup()
        segment_1.goto(position)
        self.segment.append(segment_1)

    def extend(self):
        self.add_segment(self.segment[-1].position())

    def move(self):
        for seg_num in range(len(self.segment) - 1, 0, -1):
            new_x = self.segment[seg_num - 1].xcor()
            new_y = self.segment[seg_num - 1].ycor()
            self.segment[seg_num].goto(new_x, new_y)
        self.segment[0].forward(20)

    def reset(self):
        for segment in self.segment:
            segment.hideturtle()
        self.segment.clear()
        self.create_snake()

    def up(self):
        self.segment[0].setheading(90)
    def down(self):
        self.segment[0].setheading(270)
    def right(self):
        self.segment[0].setheading(0)
    def left(self):
        self.segment[0].setheading(180)

    

    

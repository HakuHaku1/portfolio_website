from turtle import Turtle
import random

class Food(Turtle):
    def __init__(self):
        super().__init__()
        self.shape("circle")
        self.penup()
        self.shapesize(0.5, 0.5)
        self.color("white")
        self.speed("fastest")
        self.refresh()

    def refresh(self):
        max_coord = 260
        ran_x = random.randint(-max_coord, max_coord)
        ran_y = random.randint(-max_coord, max_coord)
        self.goto(ran_x, ran_y)

from turtle import Turtle

class scoreboard(Turtle):
    def __init__(self):
        super().__init__()
        self.score = 0
        self.color("white")
        self.penup()
        self.goto(0, 270)
        self.hideturtle()
        self.show_score()

    def show_score(self):
        self.clear()
        self.write(f"Score: {self.score}", align="center", font=("arial", 16, "bold"))

    def increase(self):
        self.score += 1
        self.show_score()

    def reset(self):
        self.score = 0
        self.show_score()





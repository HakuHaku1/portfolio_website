from turtle import Turtle

class Gameover(Turtle):
    def __init__(self):
        super().__init__()
        self.hideturtle()
        self.color("red")
        self.penup()

    def Lost(self):
        self.clear()
        self.goto(0, 20)
        self.write("GAME OVER", align="center", font=("arial", 20, "bold"))
        self.goto(0, -20)
        self.write("Press R to Restart or Q to Quit", align="center", font=("arial", 14, "normal"))



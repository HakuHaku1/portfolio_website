from turtle import Screen, Turtle
from snake import Snake
from food import Food
from score import scoreboard
from gameover import Gameover
import time

SCREEN_SIZE = 600
BORDER_MARGIN = 20
BORDER_LIMIT = (SCREEN_SIZE // 2) - BORDER_MARGIN

screen = Screen()
screen.setup(width=SCREEN_SIZE, height=SCREEN_SIZE)
screen.bgcolor("black")
screen.title("SNAKE ACTIVITY")
screen.tracer(0)

border = Turtle()
border.color("white")
border.hideturtle()
border.penup()
border.goto(-BORDER_LIMIT - 10, -BORDER_LIMIT - 10)
border.pendown()
border.pensize(3)
for _ in range(4):
    border.forward((BORDER_LIMIT + 10) * 2)
    border.left(90)
border.penup()

player = Snake()
food_distribution = Food()
Score = scoreboard()
games = Gameover()

restart_requested = False
quit_requested = False

def restart_game():
    global restart_requested
    restart_requested = True

def quit_game():
    global quit_requested
    quit_requested = True

screen.listen()
screen.onkey(player.up, "Up")
screen.onkey(player.down, "Down")
screen.onkey(player.left, "Left")
screen.onkey(player.right, "Right")
screen.onkey(restart_game, "r")
screen.onkey(restart_game, "R")
screen.onkey(quit_game, "q")
screen.onkey(quit_game, "Q")

while True:
    restart_requested = False
    quit_requested = False
    moving_snake = True
    Score.reset()
    games.clear()
    player.reset()
    food_distribution.refresh()

    while moving_snake:
        screen.update()
        time.sleep(0.1)
        player.move()

        if player.segment[0].distance(food_distribution) < 15:
            food_distribution.refresh()
            player.extend()
            Score.increase()

        head = player.segment[0]

        for segment in player.segment[1:]:
            if head.distance(segment) < 15:
                moving_snake = False
                break

        if head.xcor() > BORDER_LIMIT or head.xcor() < -BORDER_LIMIT or head.ycor() > BORDER_LIMIT or head.ycor() < -BORDER_LIMIT:
            moving_snake = False

    games.Lost()

    while not (restart_requested or quit_requested):
        screen.update()
        time.sleep(0.1)

    if quit_requested:
        break

screen.bye()

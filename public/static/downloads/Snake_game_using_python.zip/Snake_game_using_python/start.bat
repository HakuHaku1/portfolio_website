@echo off
cd /d "%~dp0"
if exist venv\Scripts\activate.bat (
    call venv\Scripts\activate.bat
)
python GUI\snake_game.py 2>nul
if errorlevel 1 (
    py GUI\snake_game.py 2>nul
    if errorlevel 1 (
        echo.
        echo Failed to start the game. Make sure Python is installed or run setup.bat first.
        pause
    )
)

# Snake Game in Python

A simple Snake game built with Python's `turtle` graphics library. This project demonstrates basic game mechanics such as movement, collision detection, score tracking, border control, and restart/quit flow.

## Features

- Classic Snake gameplay
- White border-based play area
- Food spawning within the active board
- Score display
- Game over screen with restart (`R`) and quit (`Q`) controls
- Easy setup using `setup.bat` and `start.bat`

## Requirements

- Windows 10 or later
- Python 3.8 or newer

## Setup

1. Open a command prompt in the project root directory.
2. Run `setup.bat`.

This will:

- verify that Python is installed
- create a `venv` virtual environment
- activate the virtual environment
- upgrade `pip`

## How to Run

After setup, run `start.bat` from the project root. This will launch the game using the virtual environment if present.

## Controls

- `Up` arrow: move snake up
- `Down` arrow: move snake down
- `Left` arrow: move snake left
- `Right` arrow: move snake right
- `R`: restart the game after a game over
- `Q`: quit the game after a game over

## Project Structure

- `setup.bat` - prepares the Python virtual environment
- `start.bat` - launches the game
- `GUI/snake_game.py` - main game loop and input handling
- `GUI/snake.py` - snake body and movement logic
- `GUI/food.py` - food creation and respawn logic
- `GUI/score.py` - score display and reset handling
- `GUI/gameover.py` - game over text and user prompts

## Customization

To change the window size or board layout, update `GUI/snake_game.py`:

- `SCREEN_SIZE` controls the window dimensions
- `BORDER_MARGIN` controls the gap between the border and the window edge

To modify food spawn limits, update `GUI/food.py`:

- `max_coord` controls the range where food can appear inside the border

## Notes

- Keep the `venv` directory in `.gitignore` to avoid committing environment files.
- If Python is not found when running `setup.bat`, install Python and ensure it is available on your PATH.